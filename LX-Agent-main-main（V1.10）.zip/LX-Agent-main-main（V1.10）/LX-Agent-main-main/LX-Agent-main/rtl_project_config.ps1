﻿# RTL manual project configuration.
# Keep this file next to main.py and edit only the values below.

# The Agent root is detected from this configuration file's location.
$LX_AGENT_ROOT = $PSScriptRoot

# Set these two values for the RTL project being documented.
$RTL_ROOT = "<RTL工程根目录>"
$TOP_MODULE = "<顶层模块名称>"
