from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
RTL_MANUAL_PACKAGES = ROOT / "backend" / "skills" / "catalog" / "rtl-manual-generation" / "packages"
if str(RTL_MANUAL_PACKAGES) not in sys.path:
    sys.path.insert(0, str(RTL_MANUAL_PACKAGES))

from parser.pipeline.hierarchy_builder import build_project
from parser.pipeline.module_index import _parse_tcl_file_entries, resolve_explicit_verilog_files


class ParserFilelistPathTests(unittest.TestCase):
    def test_tcl_filelist_entries_keep_parenthesized_paths(self):
        with tempfile.TemporaryDirectory() as raw_tmp:
            tmp_path = Path(raw_tmp)
            filelist = tmp_path / "read_rtl_list.tcl"
            filelist.write_text(
                "\n".join(
                    [
                        "# comment-only line",
                        "set SRC_DIR sub",
                        "read_verilog -sv {leaf(child).v}",
                        'read_verilog "./top(parent).v" # trailing comment',
                        r"read_verilog escaped\(name\).v",
                        "read_verilog $SRC_DIR/nested(child).sv",
                        "plain leaf (copy).v",
                        "read_verilog -sv command leaf (copy).sv",
                    ]
                ),
                encoding="utf-8",
            )

            self.assertEqual(
                _parse_tcl_file_entries(filelist),
                [
                    "leaf(child).v",
                    "./top(parent).v",
                    "escaped(name).v",
                    "sub/nested(child).sv",
                    "plain leaf (copy).v",
                    "command leaf (copy).sv",
                ],
            )

    def test_parser_build_reads_parenthesized_verilog_filenames_from_filelists(self):
        with tempfile.TemporaryDirectory() as raw_tmp:
            tmp_path = Path(raw_tmp)
            rtl_dir = tmp_path / "rtl"
            rtl_dir.mkdir()

            (rtl_dir / "leaf(child).v").write_text(
                """
module leaf_unit(input clk, output out);
  assign out = clk;
endmodule
""".strip(),
                encoding="utf-8",
            )
            (rtl_dir / "leaf unit (copy).v").write_text(
                """
module leaf_unit_copy(input clk, output out);
  assign out = clk;
endmodule
""".strip(),
                encoding="utf-8",
            )
            (rtl_dir / "top(parent).v").write_text(
                """
module top_unit(input clk, output out);
  leaf_unit_copy u_leaf (
    .clk(clk),
    .out(out)
  );
endmodule
""".strip(),
                encoding="utf-8",
            )
            (rtl_dir / "read_rtl_list.tcl").write_text(
                "\n".join(
                    [
                        "read_verilog -sv {leaf(child).v}",
                        "leaf unit (copy).v",
                        'read_verilog "./top(parent).v"',
                    ]
                ),
                encoding="utf-8",
            )
            (rtl_dir / "rtl_top_list.tcl").write_text(
                "read_verilog {top(parent).v}\n",
                encoding="utf-8",
            )

            result = build_project(tmp_path, "rtl", tmp_path / "parser_pipeline_rtl")
            top_module = result["modules"]["top_unit"]

            self.assertGreaterEqual(set(result["modules"]), {"top_unit", "leaf_unit_copy"})
            self.assertEqual(top_module["file"].replace("\\", "/"), "rtl/top(parent).v")
            self.assertEqual(top_module["instances"][0]["module_type"], "leaf_unit_copy")

    def test_parser_build_skips_testbench_entries_from_regular_filelist(self):
        with tempfile.TemporaryDirectory() as raw_tmp:
            tmp_path = Path(raw_tmp)
            rtl_dir = tmp_path / "rtl"
            rtl_dir.mkdir()

            (rtl_dir / "mi2cv2_tb.v").write_text(
                """
module mi2cv2_tb;
endmodule
""".strip(),
                encoding="utf-8",
            )
            (rtl_dir / "top.v").write_text(
                """
module top(input clk, output out);
  assign out = clk;
endmodule
""".strip(),
                encoding="utf-8",
            )
            (rtl_dir / "read_rtl_list.tcl").write_text(
                "\n".join(
                    [
                        "IONet/IIC/missing_tb.v",
                        "mi2cv2_tb.v",
                        "top.v",
                    ]
                ),
                encoding="utf-8",
            )
            (rtl_dir / "rtl_top_list.tcl").write_text("top.v\n", encoding="utf-8")

            result = build_project(tmp_path, "rtl", tmp_path / "parser_pipeline_rtl")

            self.assertEqual(set(result["modules"]), {"top"})

    def test_explicit_top_filelist_allows_testbench_named_top(self):
        with tempfile.TemporaryDirectory() as raw_tmp:
            tmp_path = Path(raw_tmp)
            rtl_dir = tmp_path / "rtl"
            rtl_dir.mkdir()
            top_path = rtl_dir / "tb_top.v"
            top_path.write_text(
                """
module tb_top;
endmodule
""".strip(),
                encoding="utf-8",
            )
            top_list = rtl_dir / "rtl_top_list.tcl"
            top_list.write_text("tb_top.v\n", encoding="utf-8")

            self.assertEqual(
                resolve_explicit_verilog_files(tmp_path, [str(top_list)]),
                {top_path.resolve()},
            )


if __name__ == "__main__":
    unittest.main()
