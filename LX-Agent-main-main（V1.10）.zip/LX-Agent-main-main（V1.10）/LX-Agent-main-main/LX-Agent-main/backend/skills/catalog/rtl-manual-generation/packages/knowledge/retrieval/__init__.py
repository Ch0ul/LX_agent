"""Knowledge retrieval and ranking."""
