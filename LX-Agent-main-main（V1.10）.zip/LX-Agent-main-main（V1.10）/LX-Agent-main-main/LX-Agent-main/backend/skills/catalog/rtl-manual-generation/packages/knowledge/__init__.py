"""Knowledge layer package."""
