"""Discover module definitions under input roots."""

from __future__ import annotations

from pathlib import Path
import re
from typing import Dict, Iterable, List, Set

from .module_parser import find_module_name


_VERILOG_FILELIST_SUFFIXES = {".v", ".sv", ".vh"}
_TCL_COMMAND_WORDS = {
    "add_files",
    "analyze",
    "read_file",
    "read_verilog",
    "read_vhdl",
    "set",
    "source",
    "vlog",
}


def build_module_index(repo_root: Path, inputs: Iterable[str], explicit_top_paths: Set[Path]) -> Dict[str, Path]:
    module_index: Dict[str, Path] = {}
    for file_path in discover_verilog_files(repo_root, inputs, explicit_top_paths):
        module_name = find_module_name(file_path)
        if module_name and module_name not in module_index:
            module_index[module_name] = file_path
    return module_index


def resolve_explicit_verilog_files(repo_root: Path, entries: Iterable[str]) -> Set[Path]:
    files: List[Path] = []
    for item in entries:
        path = _resolve_input_path(repo_root, item)
        if not path.exists():
            raise FileNotFoundError(path)
        if path.is_file() and path.suffix.lower() == ".tcl":
            files.extend(_expand_tcl_file_list(path, include_testbenches=True))
        elif path.is_file() and _is_verilog_source_file(path):
            files.append(path.resolve())
    return set(files)


def discover_verilog_files(repo_root: Path, inputs: Iterable[str], explicit_top_paths: Set[Path]) -> List[Path]:
    files: List[Path] = []
    for item in inputs:
        path = _resolve_input_path(repo_root, item)
        if path.is_file() and path.suffix.lower() == ".tcl":
            files.extend(_expand_tcl_file_list(path, explicit_top_paths))
            continue
        if path.is_file():
            if _should_include_file(path, explicit_top_paths):
                files.append(path)
            continue
        if not path.is_dir():
            continue
        for pattern in ("*.v", "*.sv"):
            for file_path in sorted(path.rglob(pattern)):
                if _should_include_file(file_path, explicit_top_paths):
                    files.append(file_path)
    return sorted(set(files))


def _should_include_file(path: Path, explicit_top_paths: Set[Path]) -> bool:
    if not _is_verilog_source_file(path):
        return False
    if path in explicit_top_paths:
        return True
    name = path.name.lower()
    return not (
        name.endswith("_tb.v")
        or name.endswith("_tb.sv")
        or name.startswith("tb_")
    )


def _resolve_input_path(repo_root: Path, item: str) -> Path:
    path = Path(item)
    if not path.is_absolute():
        path = repo_root / item
    return path.resolve()


def _expand_tcl_file_list(
    tcl_path: Path,
    explicit_top_paths: Set[Path] | None = None,
    *,
    include_testbenches: bool = False,
) -> List[Path]:
    explicit_top_paths = explicit_top_paths or set()
    files: List[Path] = []
    for entry in _parse_tcl_file_entries(tcl_path):
        if not _is_verilog_like_entry(entry):
            continue
        files.extend(
            _resolve_tcl_entry_matches(
                tcl_path,
                entry,
                explicit_top_paths,
                include_testbenches=include_testbenches,
            )
        )
    return files


def _parse_tcl_file_entries(tcl_path: Path) -> List[str]:
    entries: List[str] = []
    variables: Dict[str, str] = {}
    for line in _iter_tcl_logical_lines(tcl_path.read_text(encoding="utf-8", errors="ignore")):
        words = _split_tcl_words(line)
        if not words:
            continue

        command = words[0].lower()
        if command == "set" and len(words) >= 3:
            variables[words[1]] = _normalize_tcl_path_entry(words[2])
            continue

        joined_entry = _joined_file_entry(words, variables)
        if joined_entry:
            entries.append(joined_entry)
            continue

        for word in words:
            entry = _normalize_tcl_path_entry(_expand_tcl_variables(word, variables))
            if _is_tcl_file_entry_token(entry):
                entries.append(entry)
    return entries


def _iter_tcl_logical_lines(text: str) -> Iterable[str]:
    pending = ""
    for raw_line in text.splitlines():
        line = raw_line.rstrip()
        if _has_line_continuation(line):
            pending += line[:-1].rstrip() + " "
            continue
        current = pending + line
        pending = ""
        yield current
    if pending:
        yield pending


def _has_line_continuation(line: str) -> bool:
    backslashes = 0
    for char in reversed(line):
        if char != "\\":
            break
        backslashes += 1
    return backslashes % 2 == 1


def _split_tcl_words(line: str) -> List[str]:
    words: List[str] = []
    current: List[str] = []
    brace_depth = 0
    in_quote = False
    index = 0

    def flush_current() -> None:
        if current:
            words.append("".join(current))
            current.clear()

    while index < len(line):
        char = line[index]

        if brace_depth:
            if char == "{":
                brace_depth += 1
                current.append(char)
            elif char == "}":
                brace_depth -= 1
                if brace_depth:
                    current.append(char)
            else:
                current.append(char)
            index += 1
            continue

        if in_quote:
            if char == '"':
                in_quote = False
                index += 1
                continue
            if char == "\\":
                consumed, next_index = _consume_tcl_escape(line, index)
                current.append(consumed)
                index = next_index
                continue
            current.append(char)
            index += 1
            continue

        if char.isspace():
            flush_current()
            index += 1
            continue
        if char == "#" and not current:
            break
        if char == "{":
            brace_depth = 1
            index += 1
            continue
        if char == '"':
            in_quote = True
            index += 1
            continue
        if char == "\\":
            consumed, next_index = _consume_tcl_escape(line, index)
            current.append(consumed)
            index = next_index
            continue

        current.append(char)
        index += 1

    flush_current()
    return words


def _consume_tcl_escape(text: str, index: int) -> tuple[str, int]:
    if index + 1 >= len(text):
        return "\\", index + 1

    next_char = text[index + 1]
    if next_char in {" ", "\t", "{", "}", '"', "'", "\\", "(", ")", "#", ";"}:
        return next_char, index + 2
    return "\\", index + 1


def _expand_tcl_variables(value: str, variables: Dict[str, str]) -> str:
    def replace(match: re.Match[str]) -> str:
        name = match.group(1) or match.group(2) or ""
        return variables.get(name, match.group(0))

    return re.sub(r"\$\{([A-Za-z_]\w*)\}|\$([A-Za-z_]\w*)", replace, value)


def _normalize_tcl_path_entry(token: str) -> str:
    entry = token.strip().strip(";")
    replacements = {
        r"\ ": " ",
        r"\(": "(",
        r"\)": ")",
        r"\{": "{",
        r"\}": "}",
        '\\"': '"',
        "\\'": "'",
    }
    for escaped, literal in replacements.items():
        entry = entry.replace(escaped, literal)
    if entry.endswith("]") and _is_verilog_like_entry(entry[:-1]):
        entry = entry[:-1]
    return entry.strip()


def _is_tcl_file_entry_token(entry: str) -> bool:
    if not entry:
        return False
    if entry.lower() in _TCL_COMMAND_WORDS:
        return False
    if entry.startswith("-") or entry.startswith("+"):
        return False
    return _is_verilog_like_entry(entry)


def _joined_file_entry(words: List[str], variables: Dict[str, str]) -> str:
    if not words:
        return ""

    command = words[0].lower()
    if command in _TCL_COMMAND_WORDS:
        if command == "set":
            return ""
        candidates = [
            _normalize_tcl_path_entry(_expand_tcl_variables(word, variables))
            for word in words[1:]
        ]
        candidates = [
            item
            for item in candidates
            if item and not item.startswith("-") and not item.startswith("+")
        ]
    else:
        candidates = [
            _normalize_tcl_path_entry(_expand_tcl_variables(word, variables))
            for word in words
        ]

    if len(candidates) <= 1:
        return ""
    if all(_is_tcl_file_entry_token(item) for item in candidates):
        return ""

    joined = " ".join(candidates).strip()
    return joined if _is_verilog_like_entry(joined) else ""


def _resolve_tcl_entry_matches(
    tcl_path: Path,
    entry: str,
    explicit_top_paths: Set[Path],
    *,
    include_testbenches: bool = False,
) -> List[Path]:
    manifest_root = tcl_path.parent
    direct_path = (manifest_root / entry).resolve()
    matches: List[Path] = []
    if direct_path.exists() and direct_path.is_file():
        if _should_include_tcl_entry_file(direct_path, explicit_top_paths, include_testbenches):
            matches.append(direct_path)
        return matches
    else:
        entry_matches = [
            path.resolve()
            for path in manifest_root.rglob("*")
            if path.is_file()
            and _matches_tcl_entry(path, entry, manifest_root)
            and _is_verilog_source_file(path.resolve())
        ]
        matches.extend(
            path
            for path in entry_matches
            if _should_include_tcl_entry_file(path, explicit_top_paths, include_testbenches)
        )
        if entry_matches and not matches:
            return []

    if matches:
        unique_matches = sorted(set(matches))
        if len(unique_matches) == 1:
            return unique_matches
        return [_select_preferred_match(unique_matches, manifest_root)]

    if Path(entry).suffix.lower() in {".v", ".sv"}:
        if not include_testbenches and _is_testbench_source_name(Path(entry).name):
            return []
        search_hint = f"{direct_path}; {manifest_root}/**/{Path(entry).name}"
        format_hint = _missing_entry_format_hint(entry)
        raise FileNotFoundError(
            f"{entry} referenced by {tcl_path} was not found; tried {search_hint}{format_hint}"
        )
    return []


def _should_include_tcl_entry_file(path: Path, explicit_top_paths: Set[Path], include_testbenches: bool) -> bool:
    if not _is_verilog_source_file(path):
        return False
    if include_testbenches:
        return True
    return _should_include_file(path, explicit_top_paths)


def _missing_entry_format_hint(entry: str) -> str:
    if entry.startswith("(") or entry.startswith("[") or entry.startswith("{"):
        return (
            "; hint: this looks like a path fragment from an unquoted filelist "
            "entry with spaces. Wrap file paths in {...} or regenerate the "
            "filelist with one full path per line."
        )
    return ""


def _is_verilog_like_entry(entry: str) -> bool:
    return Path(entry).suffix.lower() in _VERILOG_FILELIST_SUFFIXES


def _is_verilog_source_file(path: Path) -> bool:
    return path.suffix.lower() in {".v", ".sv"}


def _is_testbench_source_name(name: str) -> bool:
    lowered = name.lower()
    return lowered.endswith("_tb.v") or lowered.endswith("_tb.sv") or lowered.startswith("tb_")


def _select_preferred_match(matches: List[Path], manifest_root: Path) -> Path:
    return min(matches, key=lambda path: _path_preference_key(path, manifest_root))


def _path_preference_key(path: Path, manifest_root: Path) -> tuple[int, int, int, str]:
    try:
        relative = path.relative_to(manifest_root)
    except ValueError:
        relative = path
    lowered_parts = [part.lower() for part in relative.parts[:-1]]
    suspicious_penalty = sum(
        1
        for part in lowered_parts
        if any(token in part for token in ("backup", "copy", "old"))
    )
    return (
        suspicious_penalty,
        len(relative.parts),
        len(str(relative)),
        str(relative),
    )


def _matches_tcl_entry(path: Path, entry: str, manifest_root: Path) -> bool:
    entry_path = Path(entry)
    if entry_path.is_absolute():
        return path.resolve() == entry_path.resolve()

    try:
        relative = path.relative_to(manifest_root)
    except ValueError:
        return False
    relative_text = relative.as_posix()
    if "/" in entry or "\\" in entry:
        normalized_entry = entry.replace("\\", "/")
        while normalized_entry.startswith("./"):
            normalized_entry = normalized_entry[2:]
        return relative_text == normalized_entry
    return path.name == entry
