[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [string]$ConfigPath
)

$ErrorActionPreference = "Stop"

if ([string]::IsNullOrWhiteSpace($ConfigPath)) {
    $ConfigPath = Join-Path $PSScriptRoot "rtl_project_config.ps1"
}

if (-not (Test-Path -LiteralPath $ConfigPath -PathType Leaf)) {
    throw "RTL project configuration file does not exist: $ConfigPath"
}

$ConfigPath = (Get-Item -LiteralPath $ConfigPath).FullName
. $ConfigPath

if ([string]::IsNullOrWhiteSpace($LX_AGENT_ROOT)) {
    throw "LX_AGENT_ROOT is empty in configuration file: $ConfigPath"
}

if ([string]::IsNullOrWhiteSpace($RTL_ROOT) -or $RTL_ROOT -match '^<.*>$') {
    throw "RTL_ROOT is not configured in: $ConfigPath"
}

if ([string]::IsNullOrWhiteSpace($TOP_MODULE) -or $TOP_MODULE -match '^<.*>$') {
    throw "TOP_MODULE is not configured in: $ConfigPath"
}

if (-not (Test-Path -LiteralPath $LX_AGENT_ROOT -PathType Container)) {
    throw "LX-Agent root does not exist: $LX_AGENT_ROOT"
}

if (-not (Test-Path -LiteralPath $RTL_ROOT -PathType Container)) {
    throw "RTL project root does not exist: $RTL_ROOT"
}

$LX_AGENT_ROOT = (Get-Item -LiteralPath $LX_AGENT_ROOT).FullName
$RTL_ROOT = (Get-Item -LiteralPath $RTL_ROOT).FullName
$TOP_MODULE = $TOP_MODULE.Trim()

$generatorPath = Join-Path $LX_AGENT_ROOT "generate_rtl_tcl.ps1"
$mainPath = Join-Path $LX_AGENT_ROOT "main.py"

if (-not (Test-Path -LiteralPath $mainPath -PathType Leaf)) {
    throw "LX_AGENT_ROOT does not contain main.py: $LX_AGENT_ROOT"
}

if (-not (Test-Path -LiteralPath $generatorPath -PathType Leaf)) {
    throw "Tcl generator does not exist: $generatorPath"
}

# Export the normalized configuration to the calling PowerShell session. This
# keeps the variables available for the manually executed Parser/Build stages.
Set-Variable -Name LX_AGENT_ROOT -Value $LX_AGENT_ROOT -Scope 1
Set-Variable -Name RTL_ROOT -Value $RTL_ROOT -Scope 1
Set-Variable -Name TOP_MODULE -Value $TOP_MODULE -Scope 1

Write-Host ""
Write-Host "================================"
Write-Host "RTL manual configuration"
Write-Host "Agent root :" $LX_AGENT_ROOT
Write-Host "RTL root   :" $RTL_ROOT
Write-Host "Top module :" $TOP_MODULE
Write-Host "================================"

& $generatorPath -ProjectRoot $RTL_ROOT -TopModule $TOP_MODULE

$readTcl = Join-Path $RTL_ROOT "read_rtl_list.tcl"
$topTcl = Join-Path $RTL_ROOT "rtl_top_list.tcl"

if (-not (Test-Path -LiteralPath $readTcl -PathType Leaf)) {
    throw "Tcl generation did not create: $readTcl"
}

if (-not (Test-Path -LiteralPath $topTcl -PathType Leaf)) {
    throw "Tcl generation did not create: $topTcl"
}

$rtlEntries = @(Get-Content -LiteralPath $readTcl | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
$topEntries = @(Get-Content -LiteralPath $topTcl | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })

if ($rtlEntries.Count -eq 0) {
    throw "read_rtl_list.tcl is empty: $readTcl"
}

if ($topEntries.Count -ne 1) {
    throw "rtl_top_list.tcl must contain exactly one entry: $topTcl"
}

Write-Host ""
Write-Host "========== Tcl verification =========="
Write-Host ""
Write-Host "read_rtl_list.tcl first 10 lines:"
$rtlEntries | Select-Object -First 10
Write-Host ""
Write-Host "rtl_top_list.tcl:"
$topEntries
Write-Host ""
Write-Host "Tcl generation and verification succeeded."
Write-Host "The configuration variables are available for the next manual stages."
