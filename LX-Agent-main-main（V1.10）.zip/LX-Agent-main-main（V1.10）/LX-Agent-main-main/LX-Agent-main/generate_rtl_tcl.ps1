[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [string]$ProjectRoot,

    [Parameter(Mandatory = $false)]
    [string]$TopModule,

    [Parameter(Mandatory = $false)]
    [string]$OutputDirectory
)

$ErrorActionPreference = "Stop"

# When no advanced parameters are supplied, inherit the workflow variables
# configured by the user in the calling PowerShell session.
if ([string]::IsNullOrWhiteSpace($ProjectRoot)) {
    try {
        $ProjectRoot = Get-Variable -Name RTL_ROOT -Scope 1 -ValueOnly -ErrorAction Stop
    }
    catch {
        $ProjectRoot = $null
    }
}

if ([string]::IsNullOrWhiteSpace($TopModule)) {
    try {
        $TopModule = Get-Variable -Name TOP_MODULE -Scope 1 -ValueOnly -ErrorAction Stop
    }
    catch {
        $TopModule = $null
    }
}

if ([string]::IsNullOrWhiteSpace($ProjectRoot)) {
    throw "ProjectRoot is empty. Set `$RTL_ROOT before running this script."
}

if ([string]::IsNullOrWhiteSpace($TopModule)) {
    throw "TopModule is empty. Set `$TOP_MODULE before running this script."
}

if (-not (Test-Path -LiteralPath $ProjectRoot -PathType Container)) {
    throw "RTL project path does not exist: $ProjectRoot"
}

$ProjectRoot = (Get-Item -LiteralPath $ProjectRoot).FullName
if ([string]::IsNullOrWhiteSpace($OutputDirectory)) {
    $OutputDirectory = $ProjectRoot
}

if (-not (Test-Path -LiteralPath $OutputDirectory -PathType Container)) {
    New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
}
$OutputDirectory = (Get-Item -LiteralPath $OutputDirectory).FullName

$rootPrefix = $ProjectRoot
if (-not $rootPrefix.EndsWith([System.IO.Path]::DirectorySeparatorChar.ToString())) {
    $rootPrefix += [System.IO.Path]::DirectorySeparatorChar
}

Write-Host ""
Write-Host "================================"
Write-Host "RTL project:" $ProjectRoot
Write-Host "Top module :" $TopModule
Write-Host "Tcl output :" $OutputDirectory
Write-Host "================================"

$rtlFiles = @(
    Get-ChildItem -LiteralPath $ProjectRoot -Recurse -File |
        Where-Object {
            $_.Extension.ToLowerInvariant() -in @(".v", ".sv") -and
            $_.Name -notmatch "(?i)_tb\.(v|sv)$" -and
            $_.Name -notmatch "(?i)^tb" -and
            $_.Name -notmatch "(?i)copy"
        } |
        Sort-Object FullName
)

if ($rtlFiles.Count -eq 0) {
    throw "No .v/.sv RTL files were found under: $ProjectRoot"
}

Write-Host ""
Write-Host "RTL files found:" $rtlFiles.Count

$rtlList = @(
    foreach ($file in $rtlFiles) {
        if (-not $file.FullName.StartsWith($rootPrefix, [System.StringComparison]::OrdinalIgnoreCase)) {
            throw "RTL file is outside ProjectRoot: $($file.FullName)"
        }
        $file.FullName.Substring($rootPrefix.Length).Replace("\", "/")
    }
)

$utf8 = New-Object System.Text.UTF8Encoding($false)
$readTcl = Join-Path $OutputDirectory "read_rtl_list.tcl"
[System.IO.File]::WriteAllText($readTcl, (($rtlList -join "`n") + "`n"), $utf8)

Write-Host ""
Write-Host "Generated read_rtl_list.tcl:"
Write-Host $readTcl

Write-Host ""
Write-Host "Searching for top module:" $TopModule

# Match normal declarations and declarations prefixed with Verilog attributes,
# for example: (* dont_touch = "yes" *) module Slot #(...)
$topPattern = "^\s*(?:\(\*.*?\*\)\s*)*module\s+(?:automatic\s+)?" +
    [regex]::Escape($TopModule) +
    "(?=\s|#|\(|;)"

$topMatches = @(
    Select-String -LiteralPath $rtlFiles.FullName -Pattern $topPattern |
        Select-Object -ExpandProperty Path -Unique
)

if ($topMatches.Count -eq 0) {
    throw @"
Top module was not found: $TopModule

The declaration may be split across multiple lines, or the file may have been
excluded as a testbench or copy file.
"@
}

if ($topMatches.Count -gt 1) {
    Write-Host ""
    Write-Host "Multiple files define the top module:"
    $topMatches | ForEach-Object { Write-Host $_ }
    throw "Multiple top module definitions were found. Please resolve the duplicates."
}

$topFile = $topMatches[0]
if (-not $topFile.StartsWith($rootPrefix, [System.StringComparison]::OrdinalIgnoreCase)) {
    throw "Top module file is outside ProjectRoot: $topFile"
}
$topRelative = $topFile.Substring($rootPrefix.Length).Replace("\", "/")

$topTcl = Join-Path $OutputDirectory "rtl_top_list.tcl"
[System.IO.File]::WriteAllText($topTcl, ($topRelative + "`n"), $utf8)

Write-Host ""
Write-Host "Generated rtl_top_list.tcl:"
Write-Host $topTcl
Write-Host ""
Write-Host "Top file:"
Write-Host $topRelative
Write-Host ""
Write-Host "Tcl generation completed."
